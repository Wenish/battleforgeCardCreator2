<template>
  <div class="aloha">
    <h1>Aloha~~~~~</h1>
    <br />
    <router-link to="/">back to home</router-link>
  </div>
</template>
<script>
</script>
<style lang="sass">
.aloha
  text-align: center
</style>
